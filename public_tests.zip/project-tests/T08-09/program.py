a = b()
c = b()
d = b()
f = b()
h = func()
i = func()
while cond:
    a = c
    while cond:
        h = a
        while cond:
            i = h
        a = f
    c = d
t(h, i)