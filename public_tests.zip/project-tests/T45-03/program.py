parameter = object1.get_parameter(1)
process_parameter(parameter)