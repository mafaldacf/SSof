a.f.g = c
b = a.f.g

# attributes as variables