a.b.c = c()
e = s(a.b)
h(e)