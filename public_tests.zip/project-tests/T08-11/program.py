a = b(c)
f = e(a + c)
while cond:
    h(a + f)
    if cond:
        g = h(a)
    else:
        g = h(c)
t(g)