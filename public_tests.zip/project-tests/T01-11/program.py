a=c()

g(a)

d(a)