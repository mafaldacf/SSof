a.c = b()
d = e(a + c)
h = b.s(d)
while cond:
    f(d)
    if cond:
        d = h
    else:
        c = h
t(c)