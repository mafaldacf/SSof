x = [a, 1]
x[1] = c(b)
z = x[1]
