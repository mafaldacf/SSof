b = a = 1
d = a
f = b