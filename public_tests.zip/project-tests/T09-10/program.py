a=3
c=""
while a != 3:
    c = b

# tip: c can't be tainted since the condition will never met
