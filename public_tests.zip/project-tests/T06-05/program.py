a = 1
k = ""
while a < 3:
    k = a
    a = b
    break
c(k)

# break a loop