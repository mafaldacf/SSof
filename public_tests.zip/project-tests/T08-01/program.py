a.b = d()
c = a.b