a = b = 1
d = a
f = b