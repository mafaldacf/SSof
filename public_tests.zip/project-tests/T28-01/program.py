c.attr=src.var
f(c.attr)