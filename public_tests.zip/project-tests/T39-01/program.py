a=src
while (e == ""):
    c = c + d3
    d3 = d2
    d2 = d1
    d1 = a
sink = c

