while a < b:
    a = 1
else:
    b = 1
c(a)

# while else