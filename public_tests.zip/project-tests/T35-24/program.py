declaredVariable=1234
execute(declaredVariable.get)
