a=3
if a == 1 + 2:
    c = b
else:
    c = 3

# tip: c will be tainted since the condition will be met
