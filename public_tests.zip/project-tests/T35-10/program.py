taintedVariable=QueryDict
execute(taintedVariable, get)
