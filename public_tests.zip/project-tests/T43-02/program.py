x = 1
y = 1
x += b
y += c(b)