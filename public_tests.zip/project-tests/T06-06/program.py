a = 1
k = ""
while a < 3:
    k = a
    a = b
    continue
c(k)

# continue a loop