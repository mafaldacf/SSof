varibleSanitized=mogrify(get)
execute(varibleSanitized)


varibleSanitized2=escape_string(varibleSanitized)
execute(varibleSanitized2)
