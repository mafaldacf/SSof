a=c()
x=f

if (x==f):
    d(a)

a=""