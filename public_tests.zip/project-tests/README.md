## Community Tests Repository

Welcome to the Community Repository for Testing the Projects of the Software Security course 2021/22.

Note that this repository is not supervised by the lecturers of the course, hence no guarantees of correctness of the provided examples are provided. Apply your best judgement when using these tests.

### Submitting a Test

If you want to submit a test, just create folder `TXX-NN` where `XX` is your group number and `NN` is the test sequence number for your group.  
For example, the 3rd test submitted by group 47 should be in directory `T47-03`.

1. Add the following files to that folder

 - `input.json` with the input slice  
 - `patterns.json` with the patterns to verify  
 - `output.json` with the expected output  
 - `program.py` with the original Python program for convenience of reading

2. Commit the test to the repository, with a brief commit message explaining the goal of the test.

### Running a Test

To run a test you should run:

    <your_program> <path_to_test>/program.json <path_to_test>/patterns.json

Where:  
- `<your_program>` is the command to run your project, such as `python3 my-python-program.py`, and  
- `<path_to_test>` the path to the test directory you want to use.

Then compare your result with the one in

`<path_to_test>/output.json`

### Spotting incorrect Outputs/Mistakes

In case you find a mistake, please submit an issue detailing the error and assign it to the person that submitted the original test.

If it is clear that it is an error, you can also submit a pull request with the fix and commit message `fixes #Y` where Y is the issue number.
