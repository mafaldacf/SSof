a = b
c = a
q = a
d = c
b = d
f = b