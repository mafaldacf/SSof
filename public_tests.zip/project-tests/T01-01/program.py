a=c()
d(a)
e(a)