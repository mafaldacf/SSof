a=3
if a != 1 + 2:
    c = b
else:
    c = 3

# tip: c can't be tainted since the condition will never met
