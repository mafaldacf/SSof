a=3
d=3
c=""
while True:
    c = b

# tip: c will be tainted since the condition will be met
