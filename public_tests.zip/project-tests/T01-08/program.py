
a = b()
clean = d(a)
res = e(clean)


# sanitization of a variable that becomes a source (is not indicated on patterns) 