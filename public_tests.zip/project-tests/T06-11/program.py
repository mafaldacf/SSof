if a:
    k = a
elif b:
    k = b
elif c:
    k = c
else:
    k = k
sink(k)

# elif