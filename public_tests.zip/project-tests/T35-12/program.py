sanitizedVariable=mogrify(get)
execute(sanitizedVariable)
