untainted="safe"

if 10 > 100:
    untainted=get

execute(untainted)
