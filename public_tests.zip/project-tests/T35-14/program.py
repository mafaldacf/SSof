taintedVariable=get
execute(taintedVariable)

taintedVariable=untaintedVariable
execute(taintedVariable)
