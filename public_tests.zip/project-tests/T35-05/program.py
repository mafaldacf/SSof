execute(randomVariable, get)
