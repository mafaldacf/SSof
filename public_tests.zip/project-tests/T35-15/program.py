untaintedVariable="safe"
execute(get+untaintedVariable)
