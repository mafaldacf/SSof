a=get
execute(a)
