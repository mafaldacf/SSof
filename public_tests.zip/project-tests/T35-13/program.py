execute(mogrify(get)+get)
