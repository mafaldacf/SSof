a=3
d=3
c=""
while a != d:
    c = b

# tip: c can't be tainted since the condition will never met
