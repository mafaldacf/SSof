a=3
d=3
c=""
while a == d:
    c = b

# tip: c will be tainted since the condition will be met
