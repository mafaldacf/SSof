a=""

d(a)

a=c()