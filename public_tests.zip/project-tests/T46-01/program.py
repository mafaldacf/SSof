a=b()
if (g == 0) :
    a = ""
    d = t()
elif (g == 1):
    pass
else :
    a=c(a,d)
e(a,d);