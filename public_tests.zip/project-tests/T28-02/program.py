temp=src.f()
sink.f(temp)