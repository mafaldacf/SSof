a=b('nis')
while(true):
    while(true):
        if(x==a):
            c=s(a,1)
            break
        x=x+1
q=z(c)

# robustness of inner loops
