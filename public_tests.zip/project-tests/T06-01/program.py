a, b, c = d, 2, "a"
sink(a,b)

# assignment of multiple variables