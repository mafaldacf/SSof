execute(QueryDict+get)
