a=""
d(a)
