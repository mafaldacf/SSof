d=b("")
while(true):
    while(true):
        if(x==a):
            break
            d=src()
q=sink(d)

# tip: break changing code flow
