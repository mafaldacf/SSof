a = ""
b(a)
c(a)