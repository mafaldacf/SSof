a=3
c=""
while a != 1 + 2:
    c = b

# tip: c can't be tainted since the condition will never met
