execute(mogrify(unknownVariable))
