untaintedVariable="safe"
execute(mogrify(get)+untaintedVariable)
