c = 0
d = 0
a = b()

while(c < 10):
    while(d < 10):
        e(a)