a=b('nis')
c=""
d=""
while (e == "") :
    c = d
    if (x == 33) :
        d = a
        continue
    a = s(a+1)
q=z(c)
