c = 0
d = 0
a = b()

if(c < 10):
    while(d < 10):
        e(a)