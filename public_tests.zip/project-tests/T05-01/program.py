sink(source());
sink(sanit(source()));
sink(sanit(source()), alsosource());
a = sanit(uninitvar);
sink(a)