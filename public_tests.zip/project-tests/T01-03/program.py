a=c()
x=f

while (x==f):
    d(a)

a=""