b = k
a = 1
a.b(c)

# attributes as functions/sinks