d=b("")
while(true):
    while(true):
        if(x==a):
            continue
            d=src()
q=sink(d)

# tip: continue changing code flow
