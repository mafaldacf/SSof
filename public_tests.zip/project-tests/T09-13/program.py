a=3
d=3
c=""
while False:
    c = b

# tip: c can't be tainted since the condition will never met
