a=3
c=""
while a == 1 + 2:
    c = b

# tip: c will be tainted since the condition will be met
