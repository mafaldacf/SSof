variable1="safeVariable"
execute(variable1,123)
