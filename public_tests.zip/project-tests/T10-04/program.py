a = 1
b = 1
while a==b==c:
    f = s(c)
f = c
