a=3
d=3
if False:
    c = 3
else:
    c = b

# tip: c will be tainted since the condition will fail and enter the else statement
