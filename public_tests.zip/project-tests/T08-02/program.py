a.b.c.d = d
e = a.b
f(a.b.c)
h(a)