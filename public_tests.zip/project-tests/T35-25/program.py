t = s4(source)
sink(s1(s2(s3(t))))
