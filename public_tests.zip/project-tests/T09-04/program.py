a=3
d=3
if False:
    c = b
else:
    c = 3

# tip: c can't be tainted since the condition will never met
