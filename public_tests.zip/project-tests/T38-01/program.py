a=b('nis')
c = ''
d = ''
j = ''
u = ''
s = ''
x = ''
while (e == "") :
    c = d
    d = j
    j = u
    u = s
    s = x
    x = a
g = h(c)