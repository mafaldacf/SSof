execute (random.get)
