a=b()
c=d(a)+a