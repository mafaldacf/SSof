k = 1
s(a.c)

# uninitialized attribute