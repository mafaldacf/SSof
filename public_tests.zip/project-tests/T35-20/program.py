taintedVariable=get
execute(taintedVariable)

taintedVariable=1234
execute(taintedVariable)
