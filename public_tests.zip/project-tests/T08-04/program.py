a = b.c()
d.c(a)