a=b('nis')
for i in range(100):
    c = d(a)
    e = f(c)
    a = e
g = h(a)

# for loop