a=b()
f=a
e(a)
e(f)