a = 1
b = 1
if a==b==c:
    f = s(c)
f = c
