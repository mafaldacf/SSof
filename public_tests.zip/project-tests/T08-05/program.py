a = b.c()
d = e.k(a)
d = a